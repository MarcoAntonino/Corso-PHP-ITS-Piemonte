<div class="col-sm-8 blog main">
  <form action="index.php" method="post">
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" placeholder="Username">
    </div>
    <div class="form-group">
      <label for="adminPsw">Password</label>
      <input type="password" name="psw" placeholder="password">
    </div>
    <button type="submit" name="btnLogin" class="btn btn-primary">Login</button>
  </form>

</div>
