<?php
session_start();

define('TITLE', 'Vertical Blog');
define('SUBTITLE', 'A blog for climbers');

define('DB_HOST', "localhost");
define('DB_USER', "root");
define('DB_PASS', "");
define('DB_NAME', "marcos_blog");

 ?>
